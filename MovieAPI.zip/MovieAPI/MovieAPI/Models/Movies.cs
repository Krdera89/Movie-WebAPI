﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieAPI.Models
{
    public class Movies
    {
        public int id { get; set; }
        public string MovieName { get; set; }
        public int ReleaseDate { get; set; }
        public string Director { get; set; }

    }
}
