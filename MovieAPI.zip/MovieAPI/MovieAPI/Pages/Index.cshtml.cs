﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace MovieAPI.Pages
{
    public class IndexModel : PageModel
    {   public class movies
        {

            public string imdbID { get; set; }
            public string Title { get; set; }
            public string Year { get; set; }
            public string Poster { get; set; }
            public string Details { get; set; }
        }

        public class MovieList
        {
            public int totalResults { get; set; }
            public List<movies> Search { get; set; }

        }

        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
        public IList<movies> Movies { get; set; }
        public void OnGet()
        {
            Movies = new List<movies>();
        }

        [BindProperty]
        public string MovieName { get; set; }
        public async Task<IActionResult> OnPost()
        {
            Uri mb = new Uri(" http://www.omdbapi.com/?apikey=6b50eb1e&s=" + MovieName + "&fmt=json");

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("User-Agent", "tmu.edu");
            HttpResponseMessage response = await client.GetAsync(mb.ToString());

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                var MovieResults = JsonConvert.DeserializeObject<MovieList>(data);
                Movies = MovieResults.Search;
            }
            return Page();
        }
    }
}
