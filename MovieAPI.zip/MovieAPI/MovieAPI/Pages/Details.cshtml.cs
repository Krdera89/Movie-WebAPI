using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace MovieAPI.Pages
{
    public class DetailsModel : PageModel
    {
        public class movies
        {

            public string imdbID { get; set; }
            public string Title { get; set; }
            public string Year { get; set; }
            public string Poster { get; set; }
            public string Details { get; set; }
        }

  

        private readonly ILogger<DetailsModel> _logger;

        public DetailsModel(ILogger<DetailsModel> logger)
        {
            _logger = logger;
        }

        public movies Movies;
        public async Task<ActionResult> OnGetAsync(string i)
        {
            Uri mb = new Uri(" http://www.omdbapi.com/?apikey=6b50eb1e&i=" + i + "&fmt=json");
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("User-Agent", "tmu.edu");
            HttpResponseMessage response = await client.GetAsync(mb.ToString());

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                var MovieResults = JsonConvert.DeserializeObject<movies>(data);
                Movies = MovieResults;
            }
            return Page();
        }

        [BindProperty]
        public string MovieName { get; set; }
        public async Task<IActionResult> OnPost()
        {
            Uri mb = new Uri(" http://www.omdbapi.com/?apikey=6b50eb1e&i=" + MovieName + "&fmt=json");

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("User-Agent", "tmu.edu");
            HttpResponseMessage response = await client.GetAsync(mb.ToString());

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                var MovieResults = JsonConvert.DeserializeObject<movies>(data);
                Movies = MovieResults;
            }
            return Page();
        }
    }
}
